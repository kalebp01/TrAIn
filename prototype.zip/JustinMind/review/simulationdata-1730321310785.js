function initData() {
  jimData.datamasters["chat1"] = [
    {
      "id": 1,
      "datamaster": "chat1",
      "userdata": {
        "96a50723-99f8-46df-889d-b188f73d9de1": "sample text",
        "b59989f9-a664-4dc5-9646-8d68d62641fc": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "chat1",
      "userdata": {
        "96a50723-99f8-46df-889d-b188f73d9de1": "sample text",
        "b59989f9-a664-4dc5-9646-8d68d62641fc": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "chat1",
      "userdata": {
        "96a50723-99f8-46df-889d-b188f73d9de1": "sample text",
        "b59989f9-a664-4dc5-9646-8d68d62641fc": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}