(function(window, undefined) {
  var dictionary = {
    "e6b3a048-e9ff-4e94-8757-033a30291d69": "Personal Information",
    "45758fd5-191b-442f-8b0d-b05e2977b7dd": "Sign up",
    "f0d291cb-0cd4-4468-95cb-371d4462cf0e": "Screen 1",
    "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b": "home screen",
    "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb": "reccomended workout page",
    "f2268c41-8de7-449e-8def-73bebfaeb6ac": "workout history screen",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "Board 1"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);