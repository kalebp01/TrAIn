	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Input_text_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_1"]; 

	widgets.descriptionMap[["s-Input_text_2", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_2", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_2", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_2"]; 

	widgets.descriptionMap[["s-Input_17", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Input_17", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_19"]; 

	widgets.descriptionMap[["s-Subtraction_5", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_5", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_19"]; 

	widgets.descriptionMap[["s-Input_text_3", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_3", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_3"]; 

	widgets.descriptionMap[["s-Path_3", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_3"]; 

	widgets.descriptionMap[["s-Button_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_8", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Input_text_4", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_4", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_4", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_5"]; 

	widgets.descriptionMap[["s-Input_text_5", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_5", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_6"]; 

	widgets.descriptionMap[["s-Path_5", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "45758fd5-191b-442f-8b0d-b05e2977b7dd"]] = ["Input", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_17", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_17", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Input", "s-Group_19"]; 

	widgets.descriptionMap[["s-Subtraction_5", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Subtraction_5", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Input", "s-Group_19"]; 

	widgets.descriptionMap[["s-Input_text_1", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_1", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Input", "s-Group_1"]; 

	widgets.descriptionMap[["s-Path_1", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Input", "s-Group_1"]; 

	widgets.descriptionMap[["s-Button_1", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Path_12", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Status bar 2", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_13", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_13", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Status bar 2", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_14", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Status bar 2", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_15", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Status bar 2", "s-Group_5"]; 

	widgets.descriptionMap[["s-Paragraph_2", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "f0d291cb-0cd4-4468-95cb-371d4462cf0e"]] = ["Title Button", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Path_8", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Path_6", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"]] = ["Settings", "s-Path_6"]; 

	widgets.descriptionMap[["s-Input_text_2", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_2", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_5"]; 

	widgets.descriptionMap[["s-Path_9", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_5"]; 

	widgets.descriptionMap[["s-Button_1", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Input_text_3", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_3", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_6"]; 

	widgets.descriptionMap[["s-Path_10", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_6"]; 

	widgets.descriptionMap[["s-Input_text_5", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_5", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_8"]; 

	widgets.descriptionMap[["s-Path_12", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_12", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_8"]; 

	widgets.descriptionMap[["s-Input_text_6", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Input_text_6", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_9"]; 

	widgets.descriptionMap[["s-Path_17", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Input", "s-Group_9"]; 

	widgets.descriptionMap[["s-Text_1", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Text_1", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Title Button", "s-Text_1"]; 

	widgets.descriptionMap[["s-Path_8", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"]] = ["Settings", "s-Path_8"]; 

	widgets.descriptionMap[["s-Path_4", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ["Settings", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_8", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ["Status bar 2", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f2268c41-8de7-449e-8def-73bebfaeb6ac"]] = ["Title Button", "s-Paragraph_1"]; 

	