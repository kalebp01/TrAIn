(function(window, undefined) {

  var jimLinks = {
    "45758fd5-191b-442f-8b0d-b05e2977b7dd" : {
      "Button_1" : [
        "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"
      ]
    },
    "f0d291cb-0cd4-4468-95cb-371d4462cf0e" : {
      "Button_1" : [
        "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"
      ],
      "Button_2" : [
        "45758fd5-191b-442f-8b0d-b05e2977b7dd"
      ]
    },
    "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b" : {
      "Rectangle_2" : [
        "f2268c41-8de7-449e-8def-73bebfaeb6ac"
      ],
      "Rectangle_3" : [
        "e6b3a048-e9ff-4e94-8757-033a30291d69"
      ],
      "Rectangle_1" : [
        "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"
      ],
      "Button_3" : [
        "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"
      ],
      "Button_4" : [
        "f0d291cb-0cd4-4468-95cb-371d4462cf0e"
      ],
      "Button_6" : [
        "f2268c41-8de7-449e-8def-73bebfaeb6ac"
      ]
    },
    "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb" : {
      "Button_3" : [
        "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"
      ],
      "Button_4" : [
        "f0d291cb-0cd4-4468-95cb-371d4462cf0e"
      ],
      "Button_2" : [
        "f2268c41-8de7-449e-8def-73bebfaeb6ac"
      ]
    },
    "f2268c41-8de7-449e-8def-73bebfaeb6ac" : {
      "Button_1" : [
        "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"
      ],
      "Button_6" : [
        "d4d6f3f3-abd8-47d6-8c10-953a9511ce8b"
      ],
      "Button_7" : [
        "f0d291cb-0cd4-4468-95cb-371d4462cf0e"
      ],
      "Button_9" : [
        "c03d58c4-a5d2-4f43-a0dd-d8761eba7beb"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);