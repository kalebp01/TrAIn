<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "FitnessDB";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch all data from the UserFitnessData table
$sql = "SELECT * FROM UserFitnessData";
$result = $conn->query($sql);

// Initialize an array to store fetched data
$data = array();

if ($result->num_rows > 0) {
    // Fetch all rows and add to the data array
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the database connection
$conn->close();

// Return data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>