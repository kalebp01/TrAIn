var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730321310785.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-c03d58c4-a5d2-4f43-a0dd-d8761eba7beb" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="reccomended workout page"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/c03d58c4-a5d2-4f43-a0dd-d8761eba7beb/style-1730321310785.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/c03d58c4-a5d2-4f43-a0dd-d8761eba7beb/fonts-1730321310785.css" />\
      <div class="freeLayout">\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Group 4" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Bench Press - 4 sets of 8"   datasizewidth="362.64px" datasizeheight="377.00px" dataX="34.08" dataY="205.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_3_0">Bench Press - 4 sets of 8 reps<br /><br />Pull-Ups - 4 sets of 6-10 reps <br /><br />Overhead Press - 4 sets of 8 reps<br /><br />Core:<br />Plank - 3 sets, 45 seconds hold<br /><br />Russian Twists - 3 sets of 20 <br /><br />Leg Raises - 3 sets of 15 reps</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Input_text_2" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="214.09px" datasizeheight="52.00px" dataX="176.00" dataY="258.37" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="height (in)"/></div></div>  </div></div></div>\
          <div id="s-Path_9" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="378.49" dataY="272.68"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="378.48861755046914 272.6751170212469 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_9-c03d5" d="M384.74659989634694 278.5157799133626 C384.84679920044726 278.5157799133626 384.94707341058125 278.5537866783776 385.0235025333951 278.62988720885073 L387.4857886968311 281.08671757979266 L389.95361790674355 278.62988720885073 C390.0299721235238 278.55386125018606 390.13014645894657 278.5158544851711 390.2303207943692 278.5158544851711 C390.33047016111396 278.5158544851711 390.4306195278588 278.55386125018606 390.506998713317 278.62988720885073 C390.6591828046433 278.78139226625194 390.6597321155553 279.0287469547178 390.506998713317 279.18079887204726 L388.0386201924924 281.63817610291744 L390.50093132460614 284.096100193716 C390.65309044725467 284.2476052511172 390.65366472684457 284.494959939583 390.50035704501624 284.6464649969842 C390.4239778595582 284.72249095564905 390.32382849281333 284.760497720664 390.2236791260685 284.760497720664 C390.1235047906458 284.760497720664 390.0233304552232 284.72249095564905 389.9469762384429 284.6464649969842 L387.485239385919 282.18908776611397 L385.0235025333951 284.639852963306 C384.9471982539704 284.71580435016233 384.84699894987 284.75368682883004 384.7468745518029 284.75368682883004 C384.6465504043135 284.75368682883004 384.54627619417937 284.71566763518035 384.4701217268218 284.639852963306 C384.31738832458336 284.48780104597654 384.31738832458336 284.24099321743904 384.4701217268218 284.08894130010947 L386.93240789025776 281.6376292429892 L384.46954744723166 279.180252012119 C384.31738832458336 279.0276532348613 384.31738832458336 278.780832977689 384.4706710377338 278.6293403489225 C384.5467006617023 278.55364996339557 384.6466003416689 278.5157799133626 384.74659989634694 278.5157799133626 Z M387.4886850634584 272.6751170212469 C382.53916902744203 272.6751170212469 378.4665779252191 276.7428973118044 378.4887501111251 281.67502700490223 C378.4666528312524 286.5902040402237 382.5112041082811 290.6528761619057 387.4484105861313 290.6748499881145 C387.4618437347996 290.6749121312881 387.47525191479014 290.6749369885576 387.4886600947806 290.6749369885576 C392.4381511621192 290.6749369885576 396.5107172956644 286.6071442693654 396.48857007843606 281.67502700490223 C396.5106423896309 276.75984996958096 392.4661160812801 272.69719027653355 387.52890960342995 272.67520402169004 C387.51550142343933 272.67514187851634 387.502093243449 272.6751170212469 387.4886850634584 272.6751170212469 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div onclick="CreateWorkout()" id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Filled button"   datasizewidth="184.00px" datasizeheight="50.00px" dataX="121.00" dataY="737.85" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_1_0">Create Workout</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="217.00px" datasizeheight="108.00px" dataX="104.50" dataY="88.03"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/acd0fda2-38a5-4ee7-b7f1-01f03de9bfcb.png" />\
          	</div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Input_text_3" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="214.09px" datasizeheight="52.00px" dataX="176.00" dataY="318.37" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="weight (lbs)"/></div></div>  </div></div></div>\
          <div id="s-Path_10" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="378.49" dataY="332.68"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="378.48861755046914 332.67511702124693 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_10-c03d5" d="M384.74659989634694 338.51577991336273 C384.84679920044726 338.51577991336273 384.94707341058125 338.55378667837766 385.0235025333951 338.62988720885085 L387.4857886968311 341.0867175797928 L389.95361790674355 338.62988720885085 C390.0299721235238 338.5538612501862 390.13014645894657 338.51585448517113 390.2303207943692 338.51585448517113 C390.33047016111396 338.51585448517113 390.4306195278588 338.5538612501862 390.506998713317 338.62988720885085 C390.6591828046433 338.78139226625206 390.6597321155553 339.0287469547179 390.506998713317 339.1807988720474 L388.0386201924924 341.63817610291755 L390.50093132460614 344.0961001937161 C390.65309044725467 344.2476052511173 390.65366472684457 344.4949599395831 390.50035704501624 344.6464649969843 C390.4239778595582 344.72249095564916 390.32382849281333 344.7604977206641 390.2236791260685 344.7604977206641 C390.1235047906458 344.7604977206641 390.0233304552232 344.72249095564916 389.9469762384429 344.6464649969843 L387.485239385919 342.1890877661141 L385.0235025333951 344.6398529633061 C384.9471982539704 344.71580435016244 384.84699894987 344.75368682883015 384.7468745518029 344.75368682883015 C384.6465504043135 344.75368682883015 384.54627619417937 344.71566763518047 384.4701217268218 344.6398529633061 C384.31738832458336 344.48780104597665 384.31738832458336 344.24099321743915 384.4701217268218 344.0889413001096 L386.93240789025776 341.6376292429893 L384.46954744723166 339.18025201211907 C384.31738832458336 339.02765323486136 384.31738832458336 338.78083297768904 384.4706710377338 338.6293403489226 C384.5467006617023 338.5536499633956 384.6466003416689 338.51577991336273 384.74659989634694 338.51577991336273 Z M387.4886850634584 332.67511702124693 C382.53916902744203 332.67511702124693 378.4665779252191 336.74289731180454 378.4887501111251 341.67502700490235 C378.4666528312524 346.59020404022385 382.5112041082811 350.65287616190585 387.4484105861313 350.67484998811466 C387.4618437347996 350.6749121312883 387.47525191479014 350.67493698855776 387.4886600947806 350.67493698855776 C392.4381511621192 350.67493698855776 396.5107172956644 346.60714426936556 396.48857007843606 341.67502700490235 C396.5106423896309 336.75984996958096 392.4661160812801 332.69719027653366 387.52890960342995 332.6752040216901 C387.51550142343933 332.6751418785164 387.502093243449 332.67511702124693 387.4886850634584 332.67511702124693 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_11" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="378.49" dataY="413.68"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="378.48861755046914 413.67511702124654 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-c03d5" d="M384.74659989634694 419.5157799133623 C384.84679920044726 419.5157799133623 384.94707341058125 419.55378667837726 385.0235025333951 419.6298872088504 L387.4857886968311 422.0867175797923 L389.95361790674355 419.6298872088504 C390.0299721235238 419.5538612501857 390.13014645894657 419.51585448517073 390.2303207943692 419.51585448517073 C390.33047016111396 419.51585448517073 390.4306195278588 419.5538612501857 390.506998713317 419.6298872088504 C390.6591828046433 419.7813922662516 390.6597321155553 420.02874695471746 390.506998713317 420.1807988720469 L388.0386201924924 422.6381761029171 L390.50093132460614 425.09610019371564 C390.65309044725467 425.24760525111685 390.65366472684457 425.49495993958266 390.50035704501624 425.64646499698387 C390.4239778595582 425.7224909556487 390.32382849281333 425.76049772066364 390.2236791260685 425.76049772066364 C390.1235047906458 425.76049772066364 390.0233304552232 425.7224909556487 389.9469762384429 425.64646499698387 L387.485239385919 423.18908776611363 L385.0235025333951 425.63985296330566 C384.9471982539704 425.715804350162 384.84699894987 425.7536868288297 384.7468745518029 425.7536868288297 C384.6465504043135 425.7536868288297 384.54627619417937 425.71566763518 384.4701217268218 425.63985296330566 C384.31738832458336 425.4878010459762 384.31738832458336 425.2409932174387 384.4701217268218 425.0889413001091 L386.93240789025776 422.63762924298885 L384.46954744723166 420.1802520121187 C384.31738832458336 420.02765323486096 384.31738832458336 419.78083297768865 384.4706710377338 419.62934034892214 C384.5467006617023 419.55364996339523 384.6466003416689 419.5157799133623 384.74659989634694 419.5157799133623 Z M387.4886850634584 413.67511702124654 C382.53916902744203 413.67511702124654 378.4665779252191 417.7428973118041 378.4887501111251 422.6750270049019 C378.4666528312524 427.59020404022334 382.5112041082811 431.65287616190534 387.4484105861313 431.67484998811415 C387.4618437347996 431.6749121312878 387.47525191479014 431.67493698855725 387.4886600947806 431.67493698855725 C392.4381511621192 431.67493698855725 396.5107172956644 427.60714426936505 396.48857007843606 422.6750270049019 C396.5106423896309 417.7598499695806 392.4661160812801 413.6971902765332 387.52890960342995 413.6752040216897 C387.51550142343933 413.675141878516 387.502093243449 413.67511702124654 387.4886850634584 413.67511702124654 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Input_text_5" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="214.09px" datasizeheight="52.00px" dataX="176.00" dataY="438.37" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Age"/></div></div>  </div></div></div>\
          <div id="s-Path_12" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="378.49" dataY="452.68"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="378.48861755046914 452.67511702124654 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_12-c03d5" d="M384.74659989634694 458.5157799133623 C384.84679920044726 458.5157799133623 384.94707341058125 458.55378667837726 385.0235025333951 458.6298872088504 L387.4857886968311 461.0867175797923 L389.95361790674355 458.6298872088504 C390.0299721235238 458.5538612501857 390.13014645894657 458.51585448517073 390.2303207943692 458.51585448517073 C390.33047016111396 458.51585448517073 390.4306195278588 458.5538612501857 390.506998713317 458.6298872088504 C390.6591828046433 458.7813922662516 390.6597321155553 459.02874695471746 390.506998713317 459.1807988720469 L388.0386201924924 461.6381761029171 L390.50093132460614 464.09610019371564 C390.65309044725467 464.24760525111685 390.65366472684457 464.49495993958266 390.50035704501624 464.64646499698387 C390.4239778595582 464.7224909556487 390.32382849281333 464.76049772066364 390.2236791260685 464.76049772066364 C390.1235047906458 464.76049772066364 390.0233304552232 464.7224909556487 389.9469762384429 464.64646499698387 L387.485239385919 462.18908776611363 L385.0235025333951 464.63985296330566 C384.9471982539704 464.715804350162 384.84699894987 464.7536868288297 384.7468745518029 464.7536868288297 C384.6465504043135 464.7536868288297 384.54627619417937 464.71566763518 384.4701217268218 464.63985296330566 C384.31738832458336 464.4878010459762 384.31738832458336 464.2409932174387 384.4701217268218 464.0889413001091 L386.93240789025776 461.63762924298885 L384.46954744723166 459.1802520121187 C384.31738832458336 459.02765323486096 384.31738832458336 458.78083297768865 384.4706710377338 458.62934034892214 C384.5467006617023 458.55364996339523 384.6466003416689 458.5157799133623 384.74659989634694 458.5157799133623 Z M387.4886850634584 452.67511702124654 C382.53916902744203 452.67511702124654 378.4665779252191 456.7428973118041 378.4887501111251 461.6750270049019 C378.4666528312524 466.59020404022334 382.5112041082811 470.65287616190534 387.4484105861313 470.67484998811415 C387.4618437347996 470.6749121312878 387.47525191479014 470.67493698855725 387.4886600947806 470.67493698855725 C392.4381511621192 470.67493698855725 396.5107172956644 466.60714426936505 396.48857007843606 461.6750270049019 C396.5106423896309 456.7598499695806 392.4661160812801 452.6971902765332 387.52890960342995 452.6752040216897 C387.51550142343933 452.675141878516 387.502093243449 452.67511702124654 387.4886850634584 452.67511702124654 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Path_13" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="367.49" dataY="404.68"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="367.48861755046914 404.67511702124654 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_13-c03d5" d="M373.74659989634694 410.5157799133623 C373.84679920044726 410.5157799133623 373.94707341058125 410.55378667837726 374.0235025333951 410.6298872088504 L376.4857886968311 413.0867175797923 L378.95361790674355 410.6298872088504 C379.0299721235238 410.5538612501857 379.13014645894657 410.51585448517073 379.2303207943692 410.51585448517073 C379.33047016111396 410.51585448517073 379.4306195278588 410.5538612501857 379.506998713317 410.6298872088504 C379.6591828046433 410.7813922662516 379.6597321155553 411.02874695471746 379.506998713317 411.1807988720469 L377.0386201924924 413.6381761029171 L379.50093132460614 416.09610019371564 C379.65309044725467 416.24760525111685 379.65366472684457 416.49495993958266 379.50035704501624 416.64646499698387 C379.4239778595582 416.7224909556487 379.32382849281333 416.76049772066364 379.2236791260685 416.76049772066364 C379.1235047906458 416.76049772066364 379.0233304552232 416.7224909556487 378.9469762384429 416.64646499698387 L376.485239385919 414.18908776611363 L374.0235025333951 416.63985296330566 C373.9471982539704 416.715804350162 373.84699894987 416.7536868288297 373.7468745518029 416.7536868288297 C373.6465504043135 416.7536868288297 373.54627619417937 416.71566763518 373.4701217268218 416.63985296330566 C373.31738832458336 416.4878010459762 373.31738832458336 416.2409932174387 373.4701217268218 416.0889413001091 L375.93240789025776 413.63762924298885 L373.46954744723166 411.1802520121187 C373.31738832458336 411.02765323486096 373.31738832458336 410.78083297768865 373.4706710377338 410.62934034892214 C373.5467006617023 410.55364996339523 373.6466003416689 410.5157799133623 373.74659989634694 410.5157799133623 Z M376.4886850634584 404.67511702124654 C371.53916902744203 404.67511702124654 367.4665779252191 408.7428973118041 367.4887501111251 413.6750270049019 C367.4666528312524 418.59020404022334 371.5112041082811 422.65287616190534 376.4484105861313 422.67484998811415 C376.4618437347996 422.6749121312878 376.47525191479014 422.67493698855725 376.4886600947806 422.67493698855725 C381.4381511621192 422.67493698855725 385.5107172956644 418.60714426936505 385.48857007843606 413.6750270049019 C385.5106423896309 408.7598499695806 381.4661160812801 404.6971902765332 376.52890960342995 404.6752040216897 C376.51550142343933 404.675141878516 376.502093243449 404.67511702124654 376.4886850634584 404.67511702124654 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_15" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="378.49" dataY="399.68"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="378.48861755046914 399.67511702124693 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_15-c03d5" d="M384.74659989634694 405.51577991336273 C384.84679920044726 405.51577991336273 384.94707341058125 405.55378667837766 385.0235025333951 405.62988720885085 L387.4857886968311 408.0867175797928 L389.95361790674355 405.62988720885085 C390.0299721235238 405.5538612501862 390.13014645894657 405.51585448517113 390.2303207943692 405.51585448517113 C390.33047016111396 405.51585448517113 390.4306195278588 405.5538612501862 390.506998713317 405.62988720885085 C390.6591828046433 405.78139226625206 390.6597321155553 406.0287469547179 390.506998713317 406.1807988720474 L388.0386201924924 408.63817610291755 L390.50093132460614 411.0961001937161 C390.65309044725467 411.2476052511173 390.65366472684457 411.4949599395831 390.50035704501624 411.6464649969843 C390.4239778595582 411.72249095564916 390.32382849281333 411.7604977206641 390.2236791260685 411.7604977206641 C390.1235047906458 411.7604977206641 390.0233304552232 411.72249095564916 389.9469762384429 411.6464649969843 L387.485239385919 409.1890877661141 L385.0235025333951 411.6398529633061 C384.9471982539704 411.71580435016244 384.84699894987 411.75368682883015 384.7468745518029 411.75368682883015 C384.6465504043135 411.75368682883015 384.54627619417937 411.71566763518047 384.4701217268218 411.6398529633061 C384.31738832458336 411.48780104597665 384.31738832458336 411.24099321743915 384.4701217268218 411.0889413001096 L386.93240789025776 408.6376292429893 L384.46954744723166 406.18025201211907 C384.31738832458336 406.02765323486136 384.31738832458336 405.78083297768904 384.4706710377338 405.6293403489226 C384.5467006617023 405.5536499633956 384.6466003416689 405.51577991336273 384.74659989634694 405.51577991336273 Z M387.4886850634584 399.67511702124693 C382.53916902744203 399.67511702124693 378.4665779252191 403.74289731180454 378.4887501111251 408.67502700490235 C378.4666528312524 413.59020404022385 382.5112041082811 417.65287616190585 387.4484105861313 417.67484998811466 C387.4618437347996 417.6749121312883 387.47525191479014 417.67493698855776 387.4886600947806 417.67493698855776 C392.4381511621192 417.67493698855776 396.5107172956644 413.60714426936556 396.48857007843606 408.67502700490235 C396.5106423896309 403.75984996958096 392.4661160812801 399.69719027653366 387.52890960342995 399.6752040216901 C387.51550142343933 399.6751418785164 387.502093243449 399.67511702124693 387.4886850634584 399.67511702124693 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Input field" datasizewidth="0.00px" datasizeheight="0.00px" >\
          <div id="s-Input_text_6" class="text firer focusin focusout commentable non-processed" customid="Dialog input"  datasizewidth="214.09px" datasizeheight="52.00px" dataX="176.00" dataY="558.37" ><div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="lose weight, etc..."/></div></div>  </div></div></div>\
          <div id="s-Path_17" class="path firer click commentable hidden non-processed" customid="Cancel icon"   datasizewidth="18.00px" datasizeheight="18.00px" dataX="378.49" dataY="572.68"  >\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg xmlns="http://www.w3.org/2000/svg" width="18.00006103515625" height="17.99981689453125" viewBox="378.48861755046914 572.6751170212465 18.00006103515625 17.99981689453125" preserveAspectRatio="none">\
              	  <g>\
              	    <defs>\
              	      <path id="s-Path_17-c03d5" d="M384.74659989634694 578.5157799133622 C384.84679920044726 578.5157799133622 384.94707341058125 578.5537866783772 385.0235025333951 578.6298872088503 L387.4857886968311 581.0867175797923 L389.95361790674355 578.6298872088503 C390.0299721235238 578.5538612501857 390.13014645894657 578.5158544851706 390.2303207943692 578.5158544851706 C390.33047016111396 578.5158544851706 390.4306195278588 578.5538612501857 390.506998713317 578.6298872088503 C390.6591828046433 578.7813922662515 390.6597321155553 579.0287469547175 390.506998713317 579.1807988720468 L388.0386201924924 581.6381761029171 L390.50093132460614 584.0961001937155 C390.65309044725467 584.2476052511169 390.65366472684457 584.4949599395826 390.50035704501624 584.6464649969838 C390.4239778595582 584.7224909556486 390.32382849281333 584.7604977206636 390.2236791260685 584.7604977206636 C390.1235047906458 584.7604977206636 390.0233304552232 584.7224909556486 389.9469762384429 584.6464649969838 L387.485239385919 582.1890877661136 L385.0235025333951 584.6398529633057 C384.9471982539704 584.715804350162 384.84699894987 584.7536868288296 384.7468745518029 584.7536868288296 C384.6465504043135 584.7536868288296 384.54627619417937 584.7156676351799 384.4701217268218 584.6398529633057 C384.31738832458336 584.4878010459762 384.31738832458336 584.2409932174386 384.4701217268218 584.0889413001091 L386.93240789025776 581.6376292429889 L384.46954744723166 579.1802520121186 C384.31738832458336 579.0276532348608 384.31738832458336 578.7808329776885 384.4706710377338 578.6293403489221 C384.5467006617023 578.5536499633952 384.6466003416689 578.5157799133622 384.74659989634694 578.5157799133622 Z M387.4886850634584 572.6751170212465 C382.53916902744203 572.6751170212465 378.4665779252191 576.7428973118041 378.4887501111251 581.6750270049018 C378.4666528312524 586.5902040402233 382.5112041082811 590.6528761619053 387.4484105861313 590.6748499881141 C387.4618437347996 590.6749121312878 387.47525191479014 590.6749369885572 387.4886600947806 590.6749369885572 C392.4381511621192 590.6749369885572 396.5107172956644 586.607144269365 396.48857007843606 581.6750270049018 C396.5106423896309 576.7598499695805 392.4661160812801 572.6971902765332 387.52890960342995 572.6752040216896 C387.51550142343933 572.6751418785159 387.502093243449 572.6751170212465 387.4886850634584 572.6751170212465 Z "></path>\
              	    </defs>\
              	    <g style="mix-blend-mode:normal">\
              	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-c03d5" fill="#8E8E93" fill-opacity="1.0"></use>\
              	    </g>\
              	  </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Height:"   datasizewidth="94.25px" datasizeheight="31.00px" dataX="36.08" dataY="267.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_5_0">Height:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_6" class="richtext manualfit firer ie-background commentable non-processed" customid="Experience:"   datasizewidth="127.17px" datasizeheight="35.00px" dataX="34.08" dataY="387.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_6_0">Experience:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Age:"   datasizewidth="94.25px" datasizeheight="31.00px" dataX="36.08" dataY="448.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_7_0">Age:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Gender:"   datasizewidth="94.25px" datasizeheight="31.00px" dataX="36.08" dataY="508.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_8_0">Gender:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_9" class="richtext manualfit firer ie-background commentable non-processed" customid="Goal:"   datasizewidth="94.25px" datasizeheight="31.00px" dataX="36.08" dataY="569.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_9_0">Goal:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Intensity:"   datasizewidth="103.25px" datasizeheight="35.00px" dataX="36.00" dataY="631.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_10_0">Intensity:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Height:"   datasizewidth="94.25px" datasizeheight="31.00px" dataX="36.08" dataY="267.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_4_0">Height:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_11" class="richtext manualfit firer ie-background commentable non-processed" customid="Weight:"   datasizewidth="94.25px" datasizeheight="31.00px" dataX="36.08" dataY="327.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_11_0">Weight:</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Select_4" class="dropdown firer click commentable non-processed" customid="Select 1"    datasizewidth="211.00px" datasizeheight="52.00px" dataX="176.00" dataY="377.00"  tabindex="-1"><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Experience</div></div></div></div></div><select id="s-Select_4-options" class="s-c03d58c4-a5d2-4f43-a0dd-d8761eba7beb dropdown-options" ><option selected="selected" class="option">Experience</option>\
        <option  class="option">Beginner</option>\
        <option  class="option">Intermediate</option>\
        <option  class="option">Expert</option></select></div>\
        <div id="s-Select_2" class="dropdown firer click commentable non-processed" customid="Select 1"    datasizewidth="211.00px" datasizeheight="51.00px" dataX="176.00" dataY="498.00"  tabindex="-1"><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Gender</div></div></div></div></div><select id="s-Select_2-options" class="s-c03d58c4-a5d2-4f43-a0dd-d8761eba7beb dropdown-options" ><option selected="selected" class="option">Gender</option>\
        <option  class="option">Male</option>\
        <option  class="option">Female</option></select></div>\
        <div id="s-Select_1" class="dropdown firer click commentable non-processed" customid="Select 1"    datasizewidth="211.00px" datasizeheight="52.00px" dataX="176.00" dataY="621.00"  tabindex="-1"><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Intensity</div></div></div></div></div><select id="s-Select_1-options" class="s-c03d58c4-a5d2-4f43-a0dd-d8761eba7beb dropdown-options" ><option selected="selected" class="option">Intensity</option>\
        <option  class="option">Easy</option>\
        <option  class="option">Medium</option>\
        <option  class="option">Hard</option></select></div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer pageload ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Clock"   datasizewidth="31.57px" datasizeheight="21.00px" dataX="58.00" dataY="25.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">9:41</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_8" class="path firer click commentable non-processed" customid="Settings"   datasizewidth="42.17px" datasizeheight="50.52px" dataX="15.00" dataY="108.77"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="42.1669921875" height="50.521507263183594" viewBox="14.999999999999943 108.77271644733446 42.1669921875 50.521507263183594" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_8-c03d5" d="M43.68246093043596 123.59149248564229 C45.88585707509485 123.59149248564229 47.782875498385856 121.64624705970763 48.57854116344709 118.95708323773442 L55.29016782774963 118.95708323773442 C56.310278803379575 118.95708323773442 57.1669898033146 117.69836671842671 57.1669898033146 116.18212076326571 C57.1669898033146 114.6659074016594 56.310278803379575 113.43576922150507 55.29016782774963 113.43576922150507 L48.57854116344709 113.43576922150507 C47.803302155511666 110.7180286124525 45.90605352282088 108.77271644733446 43.68246093043596 108.77271644733446 C41.45886833805104 108.77271644733446 39.561617491808335 110.7180286124525 38.786610906824606 113.43576922150507 L16.938006764209742 113.43576922150507 C15.856802862339693 113.43576922150507 14.999999999999943 114.6659074016594 14.999999999999943 116.18212076326571 C14.999999999999943 117.69836671842671 15.856802862339693 118.95708323773442 16.938006764209742 118.95708323773442 L38.786610906824606 118.95708323773442 C39.582044148934145 121.64624705970763 41.479290568073004 123.59149248564229 43.68246093043596 123.59149248564229 Z M43.68246093043596 119.70090230103492 C42.274956233134226 119.70090230103492 41.17337326550468 118.12746552193842 41.17337326550468 116.18212076326571 C41.17337326550468 114.17958673273154 42.274956233134226 112.63476243841714 43.68246093043596 112.63476243841714 C45.11061806715942 112.63476243841714 46.19177437766318 114.17958673273154 46.19177437766318 116.18212076326571 C46.19177437766318 118.12746552193842 45.11061806715942 119.70090230103492 43.68246093043596 119.70090230103492 Z M16.876799840045713 131.28713495079893 C15.856802862339693 131.28713495079893 14.999999999999943 132.51717535028922 14.999999999999943 134.03332507686022 C14.999999999999943 135.5211556606412 15.856802862339693 136.77983803432022 16.876799840045713 136.77983803432022 L23.812828650654513 136.77983803432022 C24.6084478311254 139.52602816038151 26.50564997922585 141.44285821493614 28.729149602430095 141.44285821493614 C30.932547960640903 141.44285821493614 32.82979659333169 139.52602816038151 33.62522983544122 136.77983803432022 L55.22889228347604 136.77983803432022 C56.310278803379575 136.77983803432022 57.1669898033146 135.54979763482993 57.1669898033146 134.03332507686022 C57.1669898033146 132.51717535028922 56.310278803379575 131.28713495079893 55.22889228347604 131.28713495079893 L33.62522983544122 131.28713495079893 C32.82979659333169 128.56926396752766 30.932547960640903 126.65275984851976 28.729149602430095 126.65275984851976 C26.50564997922585 126.65275984851976 24.6084478311254 128.56926396752766 23.812828650654513 131.28713495079893 L16.876799840045713 131.28713495079893 Z M28.729149602430095 137.58087896303684 C27.32164933223221 137.58087896303684 26.19963970747684 136.00744218394033 26.19963970747684 134.03332507686022 C26.19963970747684 132.03088882699006 27.32164933223221 130.51473910041906 28.729149602430095 130.51473910041906 C30.136884509131594 130.51473910041906 31.238467476761155 132.03088882699006 31.238467476761155 134.03332507686022 C31.238467476761155 136.00744218394033 30.136884509131594 137.58087896303684 28.729149602430095 137.58087896303684 Z M43.68246093043596 159.29422704837805 C45.90605352282088 159.29422704837805 47.803302155511666 157.34875191548664 48.57854116344709 154.6312068677621 L55.29016782774963 154.6312068677621 C56.310278803379575 154.6312068677621 57.1669898033146 153.40084053272506 57.1669898033146 151.88469391030213 C57.1669898033146 150.3398960012463 56.310278803379575 149.13850378424084 55.29016782774963 149.13850378424084 L48.57854116344709 149.13850378424084 C47.803302155511666 146.4206296968215 45.90605352282088 144.4751545639301 43.68246093043596 144.4751545639301 C41.479290568073004 144.4751545639301 39.561617491808335 146.4206296968215 38.786610906824606 149.13850378424084 L16.938006764209742 149.13850378424084 C15.856802862339693 149.13850378424084 14.999999999999943 150.36854107958305 14.999999999999943 151.88469391030213 C14.999999999999943 153.3721954543883 15.856802862339693 154.6312068677621 16.938006764209742 154.6312068677621 L38.786610906824606 154.6312068677621 C39.561617491808335 157.34875191548664 41.45886833805104 159.29422704837805 43.68246093043596 159.29422704837805 Z M43.68246093043596 155.40359961399392 C42.274956233134226 155.40359961399392 41.17337326550468 153.8301628348974 41.17337326550468 151.88469391030213 C41.17337326550468 149.88225766043197 42.274956233134226 148.36578199831422 43.68246093043596 148.36578199831422 C45.11061806715942 148.36578199831422 46.19177437766318 149.88225766043197 46.19177437766318 151.88469391030213 C46.19177437766318 153.8301628348974 45.11061806715942 155.40359961399392 43.68246093043596 155.40359961399392 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-c03d5" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="299.00px" datasizeheight="791.00px" datasizewidthpx="299.0" datasizeheightpx="791.0" dataX="-299.00" dataY="87.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Settings"   datasizewidth="197.64px" datasizeheight="40.00px" dataX="-276.00" dataY="118.77" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_2_0">Settings</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Home screen"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="198.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">Home screen</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Log out"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="799.85" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0">Log out</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_5" class="button multiline manualfit firer commentable non-processed" customid="Personal Information"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="274.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_5_0">Personal Information</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Workout History"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="346.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_2_0">Workout History</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="X"   datasizewidth="58.36px" datasizeheight="41.24px" dataX="-91.00" dataY="118.77" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_6_0">X</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle 7"   datasizewidth="121.12px" datasizeheight="823.00px" datasizewidthpx="121.12499999999989" datasizeheightpx="822.9999999999998" dataX="308.88" dataY="109.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
'
document.getElementById("chromeTransfer").innerHTML = content;

function sendDataToServer() {
  const data = {
    height: document.getElementById("s-Input_text_2").value,
    weight: document.getElementById("s-Input_text_3").value,
    experience: document.getElementById("s-Select_4-options").value,
    age: document.getElementById("s-Input_text_5").value,
    gender: document.getElementById("s-Select_2-options").value,
    goal: document.getElementById("s-Input_text_6").value,
    intensity: document.getElementById("s-Select_1-options").value,
    workoutButton: document.getElementById("s-Button_1").value
  };

  fetch("http://localhost:3000/saveData", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("Success:", data);
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}

// Add event listener to the button
document.getElementById("s-Button_1").addEventListener("click", sendDataToServer);