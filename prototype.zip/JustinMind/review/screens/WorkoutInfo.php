<?php

$servername = "localhost"; // This is usually localhost
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password is usually empty
$dbname = "fitnessdb"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO userfitnessdata (UserID, Height, Weight, Experience, Age, Gender, Goal, Intensity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssss", $UserID, $Height, $Weight, $Experience, $Age, $Gender, $Goal, $Intensity);

// Set parameters and execute
$UserID = $_POST['UserID'];
$Height = $_POST['Height'];
$Weight = $_POST['weight'];
$Experience= $_POST['Experience'];
$Age = $_POST['Age'];
$Gender = $_POST['Gender'];
$Intensity = $_POST['Intensity'];

if ($stmt->execute()) {
    echo "Workout successful!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>