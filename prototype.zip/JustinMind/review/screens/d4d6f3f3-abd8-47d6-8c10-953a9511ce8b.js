var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730321310785.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d4d6f3f3-abd8-47d6-8c10-953a9511ce8b" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer commentable non-processed" alignment="left" name="home screen"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d4d6f3f3-abd8-47d6-8c10-953a9511ce8b/style-1730321310785.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/d4d6f3f3-abd8-47d6-8c10-953a9511ce8b/fonts-1730321310785.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="217.00px" datasizeheight="108.00px" dataX="106.50" dataY="109.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/acd0fda2-38a5-4ee7-b7f1-01f03de9bfcb.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_2" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 2"   datasizewidth="248.00px" datasizeheight="134.59px" datasizewidthpx="248.0000000000001" datasizeheightpx="134.5859375" dataX="100.00" dataY="442.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Workout History</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 3"   datasizewidth="248.00px" datasizeheight="132.37px" datasizewidthpx="248.0" datasizeheightpx="132.3671875" dataX="100.00" dataY="594.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Personal information</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="248.00px" datasizeheight="139.00px" datasizewidthpx="248.0000000000004" datasizeheightpx="139.00111856823267" dataX="100.00" dataY="287.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Reccomended workout</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="Status bar" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Path_8" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Wifi Icon"   datasizewidth="17.14px" datasizeheight="12.33px" dataX="75.00" dataY="23.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="17.141998291015625" height="12.328323364257812" viewBox="337.8580017089844 23.000000476837158 17.141998291015625 12.328323364257812" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_8-d4d6f" d="M346.42999267578125 25.466225147247314 C348.9169921875 25.46632432937622 351.3089904785156 26.388424396514893 353.1109924316406 28.04192590713501 C353.24700927734375 28.16962480545044 353.4639892578125 28.16802453994751 353.5979919433594 28.03832483291626 L354.8949890136719 26.774824619293213 C354.9629821777344 26.709125995635986 355.0 26.62002420425415 355.0 26.52732515335083 C354.9989929199219 26.434624195098877 354.96099853515625 26.346025943756104 354.8919982910156 26.281025409698486 C350.1610107421875 21.906324863433838 342.6969909667969 21.906324863433838 337.96600341796875 26.281025409698486 C337.89801025390625 26.345924854278564 337.8590087890625 26.434624195098877 337.8580017089844 26.527225971221924 C337.8580017089844 26.619925022125244 337.8949890136719 26.709024906158447 337.9629821777344 26.774824619293213 L339.260986328125 28.03832483291626 C339.39398193359375 28.16812562942505 339.6109924316406 28.169825077056885 339.74700927734375 28.04192590713501 C341.54998779296875 26.388325214385986 343.9419860839844 25.466225147247314 346.42999267578125 25.466225147247314 Z M346.4259948730469 29.68652582168579 C347.7829895019531 29.686424732208252 349.0920104980469 30.198225498199463 350.0979919433594 31.122324466705322 C350.2349853515625 31.253525257110596 350.4490051269531 31.250624179840088 350.5820007324219 31.115925312042236 L351.8689880371094 29.79662561416626 C351.93701171875 29.72742509841919 351.9739990234375 29.633524417877197 351.9729919433594 29.536024570465088 C351.97198486328125 29.438425540924072 351.9329833984375 29.34532594680786 351.8639831542969 29.277525424957275 C348.79998779296875 26.386724948883057 344.05499267578125 26.386724948883057 340.9909973144531 29.277525424957275 C340.9219970703125 29.34532594680786 340.88299560546875 29.438425540924072 340.8819885253906 29.536024570465088 C340.8809814453125 29.633625507354736 340.91900634765625 29.727524280548096 340.9859924316406 29.79662561416626 L342.27301025390625 31.115925312042236 C342.406005859375 31.250624179840088 342.6199951171875 31.253525257110596 342.7559814453125 31.122324466705322 C343.7619934082031 30.198824405670166 345.07000732421875 29.687124729156494 346.4259948730469 29.68652582168579 Z M348.95098876953125 32.48012590408325 C348.9530029296875 32.585426807403564 348.9150085449219 32.687023639678955 348.8479919433594 32.760826587677 L346.6709899902344 35.21552324295044 C346.6080017089844 35.287724018096924 346.52099609375 35.32832384109497 346.42999267578125 35.32832384109497 C346.3389892578125 35.32832384109497 346.2519836425781 35.287724018096924 346.18798828125 35.21552324295044 L344.010986328125 32.760826587677 C343.9440002441406 32.68692445755005 343.906982421875 32.58532381057739 343.90899658203125 32.480026721954346 C343.9110107421875 32.37462663650513 343.9519958496094 32.27492570877075 344.0220031738281 32.20422410964966 C345.4119873046875 30.890425205230713 347.447998046875 30.890425205230713 348.8379821777344 32.20422410964966 C348.9079895019531 32.27492570877075 348.9490051269531 32.37472581863403 348.95098876953125 32.48012590408325 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-d4d6f" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_9" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Battery icon fill"   datasizewidth="21.00px" datasizeheight="9.00px" dataX="44.50" dataY="25.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="21.0" height="9.0" viewBox="364.5 25.0 21.0 9.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-d4d6f" d="M367.0 25.0 L383.0 25.0 C384.37145942588717 25.0 385.5 26.12854057411284 385.5 27.5 L385.5 31.5 C385.5 32.87145942588716 384.37145942588717 34.0 383.0 34.0 L367.0 34.0 C365.62854057411283 34.0 364.5 32.87145942588716 364.5 31.5 L364.5 27.5 C364.5 26.12854057411284 365.62854057411283 25.0 367.0 25.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-d4d6f" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_10" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Battery Icon"   datasizewidth="27.33px" datasizeheight="13.00px" dataX="40.00" dataY="23.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="27.3280029296875" height="13.0" viewBox="362.6719970703125 23.0 27.3280029296875 13.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-d4d6f" d="M388.6719970703125 27.7811279296875 L388.6719970703125 31.856597900390625 C389.4766845703125 31.511428833007812 390.0 30.70846939086914 390.0 29.818859100341797 C390.0 28.92926025390625 389.4766845703125 28.126300811767578 388.6719970703125 27.7811279296875 Z M383.37200927734375 24.0 C385.1804504394531 24.0 386.6719970703125 25.49152374267578 386.6719970703125 27.299999237060547 L386.6719970703125 31.700000762939453 C386.6719970703125 33.50847625732422 385.1804504394531 35.0 383.37200927734375 35.0 L366.97198486328125 35.0 C365.1635437011719 35.0 363.6719970703125 33.50847625732422 363.6719970703125 31.700000762939453 L363.6719970703125 27.299999237060547 C363.6719970703125 25.49152374267578 365.1635437011719 24.0 366.97198486328125 24.0 Z M366.97198486328125 23.0 C364.6112365722656 23.0 362.6719970703125 24.939239501953125 362.6719970703125 27.299999237060547 L362.6719970703125 31.700000762939453 C362.6719970703125 34.060760498046875 364.6112365722656 36.0 366.97198486328125 36.0 L383.37200927734375 36.0 C385.7327575683594 36.0 387.6719970703125 34.060760498046875 387.6719970703125 31.700000762939453 L387.6719970703125 27.299999237060547 C387.6719970703125 24.939239501953125 385.7327575683594 23.0 383.37200927734375 23.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-d4d6f" fill="#FFFFFF" fill-opacity="1.0" opacity="0.4"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_11" class="path firer commentable pin vpin-beginning hpin-end non-processed-pin non-processed" customid="Signal Icon"   datasizewidth="19.20px" datasizeheight="12.23px" dataX="100.00" dataY="23.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="19.20001220703125" height="12.226398468017578" viewBox="310.79998779296875 23.0 19.20001220703125 12.226398468017578" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-d4d6f" d="M330.0 24.146299362182617 C330.0 23.513198852539062 329.52197265625 23.0 328.9329833984375 23.0 L327.8669738769531 23.0 C327.2779846191406 23.0 326.79998779296875 23.513198852539062 326.79998779296875 24.146299362182617 L326.79998779296875 34.0802001953125 C326.79998779296875 34.71329879760742 327.2779846191406 35.22639846801758 327.8669738769531 35.22639846801758 L328.9329833984375 35.22639846801758 C329.52197265625 35.22639846801758 330.0 34.71329879760742 330.0 34.0802001953125 L330.0 24.146299362182617 Z M322.56597900390625 25.44529914855957 L323.63299560546875 25.44529914855957 C324.22198486328125 25.44529914855957 324.698974609375 25.97079849243164 324.698974609375 26.618999481201172 L324.698974609375 34.05270004272461 C324.698974609375 34.700897216796875 324.22198486328125 35.22639846801758 323.63299560546875 35.22639846801758 L322.56597900390625 35.22639846801758 C321.97698974609375 35.22639846801758 321.4989929199219 34.700897216796875 321.4989929199219 34.05270004272461 L321.4989929199219 26.618999481201172 C321.4989929199219 25.97079849243164 321.97698974609375 25.44529914855957 322.56597900390625 25.44529914855957 Z M318.2339782714844 28.094398498535156 L317.1669921875 28.094398498535156 C316.5780029296875 28.094398498535156 316.1009826660156 28.62649917602539 316.1009826660156 29.28299903869629 L316.1009826660156 34.03770065307617 C316.1009826660156 34.69419860839844 316.5780029296875 35.22639846801758 317.1669921875 35.22639846801758 L318.2339782714844 35.22639846801758 C318.822998046875 35.22639846801758 319.3009948730469 34.69419860839844 319.3009948730469 34.03770065307617 L319.3009948730469 29.28299903869629 C319.3009948730469 28.62649917602539 318.822998046875 28.094398498535156 318.2339782714844 28.094398498535156 Z M312.9329833984375 30.53959846496582 L311.8669738769531 30.53959846496582 C311.2779846191406 30.53959846496582 310.79998779296875 31.064199447631836 310.79998779296875 31.711299896240234 L310.79998779296875 34.0546989440918 C310.79998779296875 34.701900482177734 311.2779846191406 35.22639846801758 311.8669738769531 35.22639846801758 L312.9329833984375 35.22639846801758 C313.52197265625 35.22639846801758 314.0 34.701900482177734 314.0 34.0546989440918 L314.0 31.711299896240234 C314.0 31.064199447631836 313.52197265625 30.53959846496582 312.9329833984375 30.53959846496582 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-d4d6f" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_1" class="richtext autofit firer pageload ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed" customid="Clock"   datasizewidth="31.57px" datasizeheight="21.00px" dataX="58.00" dataY="18.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_1_0">9:41</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Path_6" class="path firer click commentable non-processed" customid="Settings"   datasizewidth="42.17px" datasizeheight="50.52px" dataX="15.00" dataY="102.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="42.1669921875" height="50.521507263183594" viewBox="14.999999999999751 102.0 42.1669921875 50.521507263183594" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-d4d6f" d="M43.68246093043577 116.81877603830783 C45.885857075094655 116.81877603830783 47.782875498385664 114.87353061237317 48.5785411634469 112.18436679039996 L55.290167827749436 112.18436679039996 C56.31027880337938 112.18436679039996 57.16698980331441 110.92565027109225 57.16698980331441 109.40940431593125 C57.16698980331441 107.89319095432494 56.31027880337938 106.66305277417061 55.290167827749436 106.66305277417061 L48.5785411634469 106.66305277417061 C47.803302155511474 103.94531216511804 45.90605352282069 102.0 43.68246093043577 102.0 C41.45886833805085 102.0 39.56161749180814 103.94531216511804 38.786610906824414 106.66305277417061 L16.93800676420955 106.66305277417061 C15.856802862339501 106.66305277417061 14.999999999999751 107.89319095432494 14.999999999999751 109.40940431593125 C14.999999999999751 110.92565027109225 15.856802862339501 112.18436679039996 16.93800676420955 112.18436679039996 L38.786610906824414 112.18436679039996 C39.582044148933946 114.87353061237317 41.47929056807281 116.81877603830783 43.68246093043577 116.81877603830783 Z M43.68246093043577 112.92818585370046 C42.274956233134034 112.92818585370046 41.17337326550448 111.35474907460396 41.17337326550448 109.40940431593125 C41.17337326550448 107.40687028539708 42.274956233134034 105.86204599108268 43.68246093043577 105.86204599108268 C45.11061806715923 105.86204599108268 46.19177437766299 107.40687028539708 46.19177437766299 109.40940431593125 C46.19177437766299 111.35474907460396 45.11061806715923 112.92818585370046 43.68246093043577 112.92818585370046 Z M16.87679984004552 124.51441850346446 C15.856802862339501 124.51441850346446 14.999999999999751 125.74445890295476 14.999999999999751 127.26060862952576 C14.999999999999751 128.74843921330674 15.856802862339501 130.00712158698576 16.87679984004552 130.00712158698576 L23.81282865065432 130.00712158698576 C24.608447831125208 132.75331171304705 26.50564997922566 134.67014176760168 28.729149602429903 134.67014176760168 C30.93254796064071 134.67014176760168 32.829796593331494 132.75331171304705 33.62522983544103 130.00712158698576 L55.22889228347585 130.00712158698576 C56.31027880337938 130.00712158698576 57.16698980331441 128.77708118749547 57.16698980331441 127.26060862952576 C57.16698980331441 125.74445890295476 56.31027880337938 124.51441850346446 55.22889228347585 124.51441850346446 L33.62522983544103 124.51441850346446 C32.829796593331494 121.79654752019319 30.93254796064071 119.8800434011853 28.729149602429903 119.8800434011853 C26.50564997922566 119.8800434011853 24.608447831125208 121.79654752019319 23.81282865065432 124.51441850346446 L16.87679984004552 124.51441850346446 Z M28.729149602429903 130.80816251570238 C27.321649332232017 130.80816251570238 26.19963970747665 129.23472573660587 26.19963970747665 127.26060862952576 C26.19963970747665 125.2581723796556 27.321649332232017 123.7420226530846 28.729149602429903 123.7420226530846 C30.136884509131402 123.7420226530846 31.238467476760963 125.2581723796556 31.238467476760963 127.26060862952576 C31.238467476760963 129.23472573660587 30.136884509131402 130.80816251570238 28.729149602429903 130.80816251570238 Z M43.68246093043577 152.5215106010436 C45.90605352282069 152.5215106010436 47.803302155511474 150.57603546815218 48.5785411634469 147.85849042042764 L55.290167827749436 147.85849042042764 C56.31027880337938 147.85849042042764 57.16698980331441 146.6281240853906 57.16698980331441 145.11197746296767 C57.16698980331441 143.56717955391184 56.31027880337938 142.36578733690638 55.290167827749436 142.36578733690638 L48.5785411634469 142.36578733690638 C47.803302155511474 139.64791324948703 45.90605352282069 137.70243811659563 43.68246093043577 137.70243811659563 C41.47929056807281 137.70243811659563 39.56161749180814 139.64791324948703 38.786610906824414 142.36578733690638 L16.93800676420955 142.36578733690638 C15.856802862339501 142.36578733690638 14.999999999999751 143.5958246322486 14.999999999999751 145.11197746296767 C14.999999999999751 146.59947900705384 15.856802862339501 147.85849042042764 16.93800676420955 147.85849042042764 L38.786610906824414 147.85849042042764 C39.56161749180814 150.57603546815218 41.45886833805085 152.5215106010436 43.68246093043577 152.5215106010436 Z M43.68246093043577 148.63088316665946 C42.274956233134034 148.63088316665946 41.17337326550448 147.05744638756295 41.17337326550448 145.11197746296767 C41.17337326550448 143.10954121309751 42.274956233134034 141.59306555097976 43.68246093043577 141.59306555097976 C45.11061806715923 141.59306555097976 46.19177437766299 143.10954121309751 46.19177437766299 145.11197746296767 C46.19177437766299 147.05744638756295 45.11061806715923 148.63088316665946 43.68246093043577 148.63088316665946 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-d4d6f" fill="#FFFFFF" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="rectangle manualfit firer commentable hidden non-processed" customid="Rectangle 7"   datasizewidth="121.12px" datasizeheight="823.00px" datasizewidthpx="121.12499999999989" datasizeheightpx="822.9999999999998" dataX="308.88" dataY="109.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="299.00px" datasizeheight="791.00px" datasizewidthpx="299.0" datasizeheightpx="791.0" dataX="-299.00" dataY="102.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_4_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Settings"   datasizewidth="197.64px" datasizeheight="40.00px" dataX="-276.00" dataY="133.77" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Text_1_0">Settings</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Home screen"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="213.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_3_0">Home screen</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_4" class="button multiline manualfit firer click commentable non-processed" customid="Log out"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="814.85" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_4_0">Log out</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_5" class="button multiline manualfit firer commentable non-processed" customid="Personal Information"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="289.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_5_0">Personal Information</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_6" class="button multiline manualfit firer click commentable non-processed" customid="Workout History"   datasizewidth="258.00px" datasizeheight="53.00px" dataX="-278.50" dataY="361.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_6_0">Workout History</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Button_7" class="button multiline manualfit firer click commentable non-processed" customid="X"   datasizewidth="58.36px" datasizeheight="41.24px" dataX="-91.00" dataY="133.77" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Button_7_0">X</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;